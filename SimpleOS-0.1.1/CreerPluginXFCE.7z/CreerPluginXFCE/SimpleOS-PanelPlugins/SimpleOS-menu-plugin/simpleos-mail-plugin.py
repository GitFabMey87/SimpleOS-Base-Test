#!/usr/bin/env python3
import gi, subprocess
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk

def on_click(icon, event):
    if event.button == 1:  # clic gauche
        subprocess.Popen(["geary"])
    elif event.button == 3:  # clic droit
        menu = Gtk.Menu()

        item_new = Gtk.MenuItem(label="Écrire un nouveau mail")
        item_new.connect("activate", lambda w: subprocess.Popen(["geary", "--compose"]))
        menu.append(item_new)

        item_inbox = Gtk.MenuItem(label="Lire ses mails")
        item_inbox.connect("activate", lambda w: subprocess.Popen(["geary"]))
        menu.append(item_inbox)

        menu.show_all()
        menu.popup_at_pointer(event)

icon = Gtk.StatusIcon()
icon.set_from_icon_name("mail-unread")  # icône système
icon.connect("button-press-event", on_click)

Gtk.main()
