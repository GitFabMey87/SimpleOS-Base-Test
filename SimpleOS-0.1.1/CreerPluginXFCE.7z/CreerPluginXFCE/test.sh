#!/bin/bash
echo "=== Vérification plugin XFCE ==="

# 1. Vérifier présence du .desktop
echo "[1] Fichiers .desktop trouvés :"
find /usr/share/xfce4/panel -name "simpleos-launcher.desktop" -print
find /usr/local/share/xfce4/panel -name "simpleos-launcher.desktop" -print

# 2. Vérifier contenu du .desktop
echo "[2] Contenu du .desktop :"
grep -E "^

\[Xfce Panel\]

|X-XFCE-Module|X-XFCE-API" /usr/share/xfce4/panel/plugins/simpleos-launcher.desktop

# 3. Vérifier présence du .so
echo "[3] Fichier .so :"
ls -l /usr/lib/x86_64-linux-gnu/xfce4/panel/plugins/libsimpleos-launcher.so

# 4. Vérifier symboles exportés
echo "[4] Symboles exportés :"
nm -D /usr/lib/x86_64-linux-gnu/xfce4/panel/plugins/libsimpleos-launcher.so | grep xfce_panel_plugin_construct

# 5. Vérifier version de la lib xfce4
