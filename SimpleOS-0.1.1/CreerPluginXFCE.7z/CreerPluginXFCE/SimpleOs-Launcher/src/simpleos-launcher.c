#include <gtk/gtk.h>
#include <libxfce4panel/xfce-panel-plugin.h>

void xfce_panel_plugin_construct(XfcePanelPlugin *plugin) {
    GtkWidget *label = gtk_label_new("SimpleOS");
    gtk_container_add(GTK_CONTAINER(plugin), label);
    gtk_widget_show_all(GTK_WIDGET(plugin));
}
